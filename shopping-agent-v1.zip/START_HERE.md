# Start Here – In Plain English

> **If you get "can't open file 'agent.py'"** – you're in the wrong folder. Open PowerShell and run:  
> `cd c:\Users\cwstg\shopping-agent-real`  
> then run `python agent.py` again. Or double‑click **Run agent.bat** in this folder.

The shopping agent is a program on your computer. To run it, you need to do a few one-time setup steps, then run the program from the **project folder**. Below is the same process in the simplest words possible.

---

## What you need

- Your project folder: `c:\Users\cwstg\shopping-agent-real`
- **Terminal** = the black (or blue) window where you type commands. In Windows you can open it by pressing the Windows key, typing **PowerShell** or **cmd**, and pressing Enter.

---

## Part A: One-time setup (do this once)

### A1. Open the terminal and go to your project

1. Press the **Windows** key on your keyboard.
2. Type: **powershell**
3. Press **Enter**. A window opens (PowerShell).
4. Type this and press **Enter**:
   ```
   cd c:\Users\cwstg\shopping-agent-real
   ```
   That tells the computer to use the shopping-agent folder. **You must do this first** or you'll get "can't open file 'agent.py'".
5. Check: your prompt should show `...\shopping-agent-real>`. If it still shows `...\cwstg>`, run the `cd` command again.

---

### A2. Create a “virtual environment”

This is a small space on your computer where the program’s tools live, so they don’t mix with other stuff.

1. In the same window, type:
   ```
   python -m venv .venv
   ```
2. Press **Enter**.
3. Wait until the line with the blinking cursor comes back. You don’t need to see any message. If nothing else appears, that’s OK.

---

### A3. “Turn on” that space

1. Type:
   ```
   .venv\Scripts\Activate.ps1
   ```
2. Press **Enter**.
3. Check the start of the line in the terminal. It should now show **(.venv)** at the beginning. That means the space is on.

---

### A4. Install what the program needs

1. Type:
   ```
   pip install -r requirements.txt
   ```
2. Press **Enter**.
3. Wait. You’ll see a lot of text. When it stops and the cursor is back, it’s done. It’s OK if you see “Successfully installed” or similar.

---

### A5. Install the browser the program will use

1. Type:
   ```
   playwright install chromium
   ```
2. Press **Enter**.
3. Wait. It’s downloading a browser. When the cursor comes back, that step is done.

---

## Part B: Run the program

### B1. Test run (no real shopping, no browser)

1. Make sure you’re still in the same terminal and you still see **(.venv)** at the start of the line.
2. If you closed the terminal, open PowerShell again, then run:
   - `cd c:\Users\cwstg\shopping-agent-real`
   - `.venv\Scripts\Activate.ps1`
3. Type:
   ```
   python agent.py --auto --dry-run
   ```
4. Press **Enter**.

You should see a list of meals and a list of groceries. No browser opens. That means the program is working.

---

### B2. Run it “for real” (it will ask you questions)

1. In the same terminal, type:
   ```
   python agent.py
   ```
2. Press **Enter**.
3. It will ask you questions. You can type answers or just press **Enter** to use the suggested answer.
4. You then **review your list**: the program shows each item with a number. You can type numbers to **remove** items you don’t want (e.g. `2,5,9`), or press Enter to keep all. We never add more than 20 items in one run, and we warn you if the list is over your budget.
5. At the end it will ask: **Add these to your online cart? (yes/no)**
   - If you type **no** → nothing happens in a browser; you’re just practicing.
   - If you type **yes** → a browser will open and the program will add only the items you kept (1 of each, up to 20). You still pay yourself on the website.

---

## Login (Woolworths / Coles)

The agent uses the **website** in a browser (not the Woolworths or Coles mobile app). It does **not** log in for you.

**What happens:**
1. When you say “yes” to adding to cart, a browser window opens and goes to Woolworths (or Coles).
2. The program then says: **“Log in to Woolworths in the browser (and set your location if asked). Then press Enter here to start adding items.”**
3. You log in on the website in that browser (same as you normally would), and set your delivery or pickup location if the site asks.
4. When you’re done, you go back to the terminal and press **Enter**. The program will then start adding items to your cart.

You only need to log in once per run. The program does not save your password or use the mobile app.

---

## If something goes wrong

- **“python is not recognized”**  
  You need Python installed. Download it from python.org (get the latest 3.x) and install it, then try again from A1.

- **“(.venv)” never appears**  
  After A3, if you don’t see (.venv), try closing the terminal, opening it again, going to the folder (A1), then running the command in A3 again.

- **You’re not sure if you’re in the right folder**  
  In the terminal, type `dir` and press Enter. You should see `agent.py`, `config.json`, `requirements.txt` in the list.

---

## Super short version

1. Open PowerShell.
2. Type: `cd c:\Users\cwstg\shopping-agent-real` then Enter.
3. Type: `python -m venv .venv` then Enter.
4. Type: `.venv\Scripts\Activate.ps1` then Enter.
5. Type: `pip install -r requirements.txt` then Enter.
6. Type: `playwright install chromium` then Enter.
7. Type: `python agent.py --auto --dry-run` then Enter.

If step 7 shows a meal plan and a grocery list, you’re done with setup. After that, use `python agent.py` when you want to run it and answer the questions.
