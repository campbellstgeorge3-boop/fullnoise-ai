"""
Compare prices for cart items between Woolworths and Coles, and prompt client to choose cheaper.
"""
from typing import Any, Dict, List, Optional, Tuple

from woolies_tool import get_woolies_price, HAS_PLAYWRIGHT
from coles_tool import get_coles_price
from prompts import ask_yes_no

# Re-export for agent
def compare_cart_prices(
    cart: List[Dict[str, Any]],
    *,
    headless: bool = False,
    dry_run: bool = False,
) -> List[Dict[str, Any]]:
    """
    For each cart item, fetch Woolworths and Coles price. Return list of
    { name, qty, woolies_price, coles_price, cheaper_at }.
    cheaper_at is "woolworths" | "coles" | "same" | None (if either price missing).
    """
    if dry_run or not HAS_PLAYWRIGHT:
        return _dry_run_comparison(cart)

    from playwright.sync_api import sync_playwright

    comparisons = []
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless)
        context = browser.new_context(
            viewport={"width": 1280, "height": 720},
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        )
        page = context.new_page()

        try:
            page.goto("https://www.woolworths.com.au/", wait_until="domcontentloaded", timeout=20000)
            page.wait_for_timeout(3000)
        except Exception:
            browser.close()
            return _dry_run_comparison(cart)

        for item in cart:
            name = item.get("name", "")
            qty = item.get("qty", 1)
            w_price, _ = get_woolies_price(page, name)
            comparisons.append({"name": name, "qty": qty, "woolies_price": w_price, "coles_price": None, "cheaper_at": None})

        try:
            page.goto("https://www.coles.com.au/", wait_until="domcontentloaded", timeout=20000)
            page.wait_for_timeout(3000)
        except Exception:
            browser.close()
            return _set_cheaper_at(comparisons)

        for i, item in enumerate(cart):
            name = item.get("name", "")
            c_price, _ = get_coles_price(page, name)
            comparisons[i]["coles_price"] = c_price
            w = comparisons[i]["woolies_price"]
            if w is not None and c_price is not None:
                if w < c_price:
                    comparisons[i]["cheaper_at"] = "woolworths"
                elif c_price < w:
                    comparisons[i]["cheaper_at"] = "coles"
                else:
                    comparisons[i]["cheaper_at"] = "same"
            else:
                comparisons[i]["cheaper_at"] = None

        browser.close()

    return comparisons


def _set_cheaper_at(comparisons: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    for c in comparisons:
        w, col = c.get("woolies_price"), c.get("coles_price")
        if w is not None and col is not None:
            c["cheaper_at"] = "woolworths" if w < col else ("coles" if col < w else "same")
        else:
            c["cheaper_at"] = None
    return comparisons


def _dry_run_comparison(cart: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Return fake comparison (e.g. no Playwright)."""
    return [
        {
            "name": item.get("name", ""),
            "qty": item.get("qty", 1),
            "woolies_price": None,
            "coles_price": None,
            "cheaper_at": None,
        }
        for item in cart if item.get("name")
    ]


def ask_client_cheaper_choices(
    comparisons: List[Dict[str, Any]],
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """
    For each item where one store is cheaper, ask client if they want the cheaper option.
    Returns (woolies_cart, coles_cart) – items to add at each store.
    """
    woolies_cart: List[Dict[str, Any]] = []
    coles_cart: List[Dict[str, Any]] = []

    for c in comparisons:
        name = c.get("name", "")
        qty = c.get("qty", 1)
        if not name:
            continue
        w_price = c.get("woolies_price")
        col_price = c.get("coles_price")
        cheaper_at = c.get("cheaper_at")

        # No prices or same price: default to Woolworths
        if cheaper_at is None or cheaper_at == "same":
            woolies_cart.append({"name": name, "qty": qty})
            continue

        if cheaper_at == "woolworths":
            w_str = f"${w_price:.2f}" if w_price is not None else "?"
            col_str = f"${col_price:.2f}" if col_price is not None else "?"
            print(f"\n  {name}: Woolworths {w_str}  |  Coles {col_str}  ->  Woolworths is cheaper.")
            if ask_yes_no("    Get this from Woolworths?", default=True):
                woolies_cart.append({"name": name, "qty": qty})
            else:
                coles_cart.append({"name": name, "qty": qty})
        else:  # cheaper_at == "coles"
            w_str = f"${w_price:.2f}" if w_price is not None else "?"
            col_str = f"${col_price:.2f}" if col_price is not None else "?"
            print(f"\n  {name}: Woolworths {w_str}  |  Coles {col_str}  ->  Coles is cheaper.")
            if ask_yes_no("    Get this from Coles and save?", default=True):
                coles_cart.append({"name": name, "qty": qty})
            else:
                woolies_cart.append({"name": name, "qty": qty})

    return woolies_cart, coles_cart
