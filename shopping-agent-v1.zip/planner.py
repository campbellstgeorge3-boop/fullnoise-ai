"""
Meal planning and cart building from recipes.
"""
from typing import Any, Dict, List, Tuple

# Recipe id -> { name, ingredients: [ (name, per_serve), ... ], serves }
RECIPES: Dict[int, Dict[str, Any]] = {
    1: {
        "name": "Pasta with tomato & basil",
        "serves": 2,
        "ingredients": [
            ("spaghetti", 75),
            ("tinned tomatoes", 200),
            ("garlic", 1),
            ("basil", 0.5),
            ("olive oil", 15),
            ("parmesan", 20),
        ],
    },
    2: {
        "name": "Stir-fry vegetables & rice",
        "serves": 2,
        "ingredients": [
            ("jasmine rice", 75),
            ("mixed stir-fry vegetables", 150),
            ("soy sauce", 15),
            ("ginger", 10),
            ("vegetable oil", 10),
        ],
    },
    3: {
        "name": "Chicken salad",
        "serves": 2,
        "ingredients": [
            ("chicken breast", 150),
            ("mixed salad leaves", 80),
            ("cherry tomatoes", 50),
            ("cucumber", 50),
            ("olive oil", 10),
            ("lemon", 0.5),
        ],
    },
    4: {
        "name": "Beans on toast",
        "serves": 1,
        "ingredients": [
            ("bread", 2),
            ("baked beans", 200),
            ("butter", 10),
        ],
    },
    5: {
        "name": "Omelette with veggies",
        "serves": 1,
        "ingredients": [
            ("eggs", 2),
            ("milk", 30),
            ("mixed vegetables frozen", 50),
            ("cheese", 30),
            ("butter", 10),
        ],
    },
    6: {
        "name": "Lentil soup",
        "serves": 4,
        "ingredients": [
            ("red lentils", 200),
            ("onion", 1),
            ("carrot", 2),
            ("celery", 2),
            ("vegetable stock", 500),
            ("cumin", 2),
            ("tin tomatoes", 200),
        ],
    },
    7: {
        "name": "Tacos",
        "serves": 2,
        "ingredients": [
            ("mince beef", 200),
            ("taco shells", 6),
            ("lettuce", 50),
            ("cheese", 50),
            ("sour cream", 50),
            ("salsa", 50),
        ],
    },
    8: {
        "name": "Oatmeal with fruit",
        "serves": 1,
        "ingredients": [
            ("rolled oats", 50),
            ("milk", 120),
            ("banana", 1),
            ("honey", 15),
        ],
    },
}


def show_recipes() -> None:
    """Print numbered recipe list."""
    for i, r in RECIPES.items():
        print(f"  {i}. {r['name']} (serves {r['serves']})")


def parse_picks(raw: str) -> List[int]:
    """Parse user input like '1,3,5' or 'all' into list of recipe ids."""
    raw = raw.strip().lower()
    if raw == "all":
        return list(RECIPES.keys())
    out = []
    for part in raw.split(","):
        part = part.strip()
        if part.isdigit():
            i = int(part)
            if i in RECIPES:
                out.append(i)
    return out


def _apply_substitutions(name: str, subs: Dict[str, str]) -> str:
    name_lower = name.lower()
    for from_val, to_val in subs.items():
        if from_val.lower() in name_lower:
            return to_val
    return name


def _scale_ingredient(qty: float, serves: int, people: int, days: int) -> float:
    """Scale ingredient for people and number of days (assuming 1 meal per recipe per day)."""
    # How many times we cook this recipe over the period
    mult = (people / serves) * days
    return qty * mult


def build_plan_and_cart(
    people: int,
    days: int,
    budget: float,
    avoid: List[str],
    picks: List[int],
    profile_subs: Dict[str, str],
) -> Tuple[List[Dict[str, Any]], str, float]:
    """
    Build meal plan text and aggregated cart (name, qty) with rough cost estimate.
    Returns (cart, meal_plan_text, estimated_total).
    """
    people = max(1, int(people))
    days = max(1, int(days))
    avoid = avoid or []
    profile_subs = profile_subs or {}
    avoid_set = {str(a).lower() for a in avoid if a}
    # Aggregate ingredients: name -> total qty
    agg: Dict[str, float] = {}
    plan_lines = []

    for rid in picks:
        if rid not in RECIPES:
            continue
        r = RECIPES[rid]
        name = r.get("name", "")
        serves = max(1, int(r.get("serves", 1)))
        plan_lines.append(f"- {name} (x{(people / serves) * days:.0f} times)")

        for ing_name, qty_per_serve in r.get("ingredients", []):
            # Skip if in avoid list
            if any(a in str(ing_name).lower() for a in avoid_set):
                continue
            try:
                qty_per_serve = float(qty_per_serve)
            except (TypeError, ValueError):
                continue
            sub_name = _apply_substitutions(str(ing_name), profile_subs)
            scaled = _scale_ingredient(qty_per_serve, serves, people, days)
            key = sub_name.strip().lower()
            agg[key] = agg.get(key, 0) + scaled

    # Convert to cart format: list of { name, qty } with sensible units
    cart = []
    for name, qty in agg.items():
        # Round quantities for display/shopping
        if qty >= 10:
            qty_rounded = round(qty)
        elif qty >= 1:
            qty_rounded = round(qty, 1)
        else:
            qty_rounded = round(qty, 2)
        cart.append({"name": name, "qty": qty_rounded})

    meal_plan_text = "\n".join(plan_lines)
    # Rough estimate: ~$2 per cart line (very rough)
    est = min(budget, len(cart) * 2.5 + 20)
    return cart, meal_plan_text, est
