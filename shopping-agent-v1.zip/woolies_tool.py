"""
Browser automation to fill Woolworths cart and fetch prices. Uses Playwright.
Run: playwright install chromium
"""
import re
from typing import Any, Dict, List, Optional, Tuple

# Optional Playwright; if missing, we dry-run
try:
    from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeout
    HAS_PLAYWRIGHT = True
except ImportError:
    HAS_PLAYWRIGHT = False


def _parse_price(text: str) -> Optional[float]:
    """Extract first $X.XX or X.XX from text."""
    if not text:
        return None
    match = re.search(r"\$?\s*(\d+\.?\d*)", text.replace(",", "."))
    return float(match.group(1)) if match else None


def get_woolies_price(page: Any, search_term: str) -> Tuple[Optional[float], Optional[str]]:
    """
    On Woolworths page: search for term, return (price, product_name) of first result.
    Returns (None, None) if not found. Caller owns page.
    """
    try:
        search_sel = "input[placeholder*='Search'], input[aria-label*='Search'], input[name='search'], #search-input"
        page.wait_for_selector(search_sel, timeout=5000)
        page.fill(search_sel, "")
        page.fill(search_sel, search_term)
        page.keyboard.press("Enter")
        page.wait_for_timeout(2500)
        # First product price: common patterns
        price_sel = "[class*='price'], [data-testid*='price'], .product-tile-price, .price"
        el = page.locator(price_sel).first
        el.wait_for(state="visible", timeout=5000)
        price_text = el.inner_text()
        price = _parse_price(price_text)
        name_sel = "a[href*='/shop/product/'], [class*='productTitle'], .product-tile-title"
        name_el = page.locator(name_sel).first
        name = name_el.inner_text().strip() if name_el.count() else None
        return (price, name)
    except Exception:
        return (None, None)


def run_woolies_fill(
    cart: List[Dict[str, Any]],
    profile: Dict[str, Any],
    *,
    headless: bool = False,
    dry_run: bool = False,
    keep_browser_open: bool = False,
) -> Dict[str, Any]:
    """
    Open Woolworths, search for each item and add to cart.
    Returns { "added": [...], "failed": [...], "dry_run": bool }.
    """
    if dry_run or not HAS_PLAYWRIGHT:
        return _dry_run_fill(cart, profile)

    cart = [item for item in cart if item.get("name")]
    if not cart:
        return {"added": [], "failed": [], "dry_run": False}

    results = {"added": [], "failed": [], "dry_run": False}
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless)
        context = browser.new_context(
            viewport={"width": 1280, "height": 720},
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        )
        page = context.new_page()
        try:
            page.goto("https://www.woolworths.com.au/", wait_until="domcontentloaded", timeout=30000)
            page.wait_for_timeout(2000)
        except Exception as e:
            results["failed"] = [{"name": item["name"], "error": str(e)} for item in cart]
            browser.close()
            return results

        input("\n  >>> Log in to Woolworths in the browser first. Nothing will be added until you are logged in and press Enter here. <<<\n  ")

        for item in cart:
            name = item.get("name", "")
            qty = item.get("qty", 1)
            if not name:
                continue
            try:
                try:
                    add_clicks = min(5, max(1, int(float(qty))))
                except (TypeError, ValueError):
                    add_clicks = 1
                search_sel = "input[placeholder*='Search'], input[aria-label*='Search'], input[name='search'], #search-input"
                page.wait_for_selector(search_sel, timeout=15000)
                page.fill(search_sel, name)
                page.keyboard.press("Enter")
                page.wait_for_timeout(3500)

                add_sel = "button:has-text('Add'), button:has-text('Add to cart'), [data-testid*='add'], .add-to-cart"
                try:
                    first_add = page.locator(add_sel).first
                    first_add.wait_for(state="visible", timeout=15000)
                    for _ in range(add_clicks - 1):
                        first_add.click()
                        page.wait_for_timeout(500)
                    first_add.click()
                    results["added"].append({"name": name, "qty": add_clicks})
                except PlaywrightTimeout:
                    results["failed"].append({"name": name, "error": "Add button not found"})
            except Exception as e:
                results["failed"].append({"name": name, "error": str(e)[:200]})

        if keep_browser_open:
            input("\nPress Enter to close the browser and finish. ")
        elif not results["added"] and results["failed"]:
            page.wait_for_timeout(5000)
        browser.close()

    return results


def _dry_run_fill(cart: List[Dict[str, Any]], profile: Dict[str, Any]) -> Dict[str, Any]:
    """Simulate fill for testing or when Playwright not installed."""
    return {
        "added": [{"name": item.get("name", ""), "qty": 1} for item in cart if item.get("name")],
        "failed": [],
        "dry_run": True,
    }
