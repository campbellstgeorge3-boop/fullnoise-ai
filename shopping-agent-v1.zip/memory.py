"""
Persistent profile for the shopping agent: preferences, substitutions, and learnings.
"""
import json
from pathlib import Path
from typing import Any, Dict

PROFILE_PATH = Path("profile.json")
DEFAULT_PROFILE: Dict[str, Any] = {
    "substitutions": {},   # e.g. {"almond milk": "oat milk"}
    "preferences": {
        "brands": {},      # e.g. {"yogurt": "chobani"}
    },
    "avoid": [],
    "default_people": 2,
    "default_days": 5,
    "default_budget": 140.0,
}


def load_profile() -> Dict[str, Any]:
    """Load profile from disk or return default."""
    if not PROFILE_PATH.exists():
        return dict(DEFAULT_PROFILE)
    try:
        raw = PROFILE_PATH.read_text(encoding="utf-8")
        data = json.loads(raw)
    except (json.JSONDecodeError, OSError):
        return dict(DEFAULT_PROFILE)
    out = dict(DEFAULT_PROFILE)
    for k, v in data.items():
        if isinstance(out.get(k), dict) and isinstance(v, dict):
            out[k] = {**out[k], **v}
        else:
            out[k] = v
    return out


def save_profile(profile: Dict[str, Any]) -> None:
    """Persist profile to disk."""
    try:
        PROFILE_PATH.write_text(json.dumps(profile, indent=2), encoding="utf-8")
    except OSError:
        pass
