"""
Full autonomous shopping agent: Plan → Act → Observe → Learn.
Run interactively (prompts) or in autonomous mode (config-driven).
"""
import argparse
import json
from pathlib import Path
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from memory import load_profile, save_profile
from planner import show_recipes, parse_picks, build_plan_and_cart
from woolies_tool import run_woolies_fill
from coles_tool import run_coles_fill
from price_compare import compare_cart_prices, ask_client_cheaper_choices
from prompts import prompt_int, prompt_float, prompt_list, ask_yes_no, ask_go_ahead

LOG_DIR = Path("run_logs")
LOG_DIR.mkdir(exist_ok=True)
CONFIG_PATH = Path("config.json")
MAX_ITEMS_TO_ADD = 20  # Never add more than this many items in one run


def cart_for_browser(cart: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """One product per ingredient, capped at MAX_ITEMS_TO_ADD."""
    items = [{"name": item["name"], "qty": 1} for item in cart if item.get("name")]
    return items[:MAX_ITEMS_TO_ADD]


def review_cart(cart: List[Dict[str, Any]], budget: float, est: float) -> List[Dict[str, Any]]:
    """
    Show numbered list. Let user type numbers to REMOVE items. Enforce budget warning and item cap.
    Returns the cart after removals (and capped to MAX_ITEMS_TO_ADD).
    """
    cart = [item for item in cart if item.get("name")]
    if not cart:
        return []
    print("\n--- Review your list (we will add 1 of each) ---")
    print(f"  Your budget: ${budget:.0f}.  This list is roughly ${est:.0f}.")
    if est > budget:
        print(f"  >>> Over budget. Remove items to stay under ${budget:.0f}, or we'll only add the first {MAX_ITEMS_TO_ADD} items.")
    for i, item in enumerate(cart, 1):
        print(f"  {i}. {item.get('name', '')}")
    print(f"\n  We will add at most {MAX_ITEMS_TO_ADD} items.")
    raw = input("  Type numbers to REMOVE (e.g. 2,5,9), or press Enter to keep all: ").strip()
    to_remove: set = set()
    for part in raw.replace(",", " ").split():
        part = part.strip()
        if part.isdigit():
            n = int(part)
            if 1 <= n <= len(cart):
                to_remove.add(n - 1)
    kept = [item for i, item in enumerate(cart) if i not in to_remove]
    if len(kept) > MAX_ITEMS_TO_ADD:
        print(f"  List has {len(kept)} items. We will only add the first {MAX_ITEMS_TO_ADD}. Rest saved in cart.json if you want to add them yourself.")
    return kept[:MAX_ITEMS_TO_ADD]


def load_config() -> Dict[str, Any]:
    """Load autonomous config from config.json if present."""
    if not CONFIG_PATH.exists():
        return {}
    try:
        return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def run_price_comparison_and_choose(
    cart: List[Dict[str, Any]],
    profile: Dict[str, Any],
    *,
    compare_prices: bool,
    dry_run: bool = False,
    headless: bool = False,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], Optional[List[Dict[str, Any]]]]:
    """
    If compare_prices: fetch Coles vs Woolworths prices, ask client for each cheaper item, return split carts.
    Otherwise: return (cart, [], None).
    Returns (woolies_cart, coles_cart, comparisons_or_none).
    """
    if not compare_prices:
        return (cart, [], None)
    print("\nChecking prices at Woolworths and Coles… one moment.")
    comparisons = compare_cart_prices(cart, dry_run=dry_run, headless=headless)
    if dry_run:
        # Fake: put all in Woolworths
        return (cart, [], comparisons)
    print("\n--- Prices ---")
    for c in comparisons:
        w, col = c.get("woolies_price"), c.get("coles_price")
        w_str = f"${w:.2f}" if w is not None else "?"
        col_str = f"${col:.2f}" if col is not None else "?"
        cheaper = c.get("cheaper_at")
        note = f"  -> {cheaper} is cheaper" if cheaper and cheaper != "same" else ""
        print(f"  {c.get('name', '')}: Woolworths {w_str}  |  Coles {col_str}{note}")
    woolies_cart, coles_cart = ask_client_cheaper_choices(comparisons)
    return (woolies_cart, coles_cart, comparisons)


def run_autonomous(profile: Dict[str, Any], auto_approve: bool, dry_run: bool, headless: bool) -> bool:
    """
    Run the agent in full autonomous mode: config → plan → act → observe → learn.
    Returns True if cart was filled (or dry-run), False if skipped.
    """
    config = load_config()
    auto = config.get("autonomous", {}) or {}
    people = int(auto.get("people", profile.get("default_people", 2)))
    days = int(auto.get("days", profile.get("default_days", 5)))
    budget = float(auto.get("budget", profile.get("default_budget", 140.0)))
    avoid = auto.get("avoid", profile.get("avoid", []))
    if not isinstance(avoid, list):
        avoid = []
    picks_raw = auto.get("recipe_picks", "all")
    if isinstance(picks_raw, list):
        picks_raw = ",".join(str(x) for x in picks_raw)
    dry_run = dry_run or auto.get("dry_run", False)
    headless = headless or auto.get("headless", False)

    picks = parse_picks(picks_raw)
    if not picks:
        print("Autonomous: no recipes selected (check config recipe_picks). Exiting.")
        return False

    cart, meal_plan_text, est = build_plan_and_cart(
        people=people,
        days=days,
        budget=budget,
        avoid=avoid,
        picks=picks,
        profile_subs=profile.get("substitutions", {}),
    )

    print("\n--- Your plan ---")
    print(meal_plan_text)
    print("\n--- Your cart ---")
    for line in cart:
        print(f"  - {line.get('name', '')} x{line.get('qty', 1)}")
    print(f"\nRough total: about ${est:.2f}.  Your budget: ${budget:.0f}.")
    if est > budget:
        print(f"  >>> Over budget. We will add at most {MAX_ITEMS_TO_ADD} items.")
    if len(cart) > MAX_ITEMS_TO_ADD:
        print(f"  >>> List has {len(cart)} items. We will only add the first {MAX_ITEMS_TO_ADD}.")
    cart = cart[:MAX_ITEMS_TO_ADD]

    compare_prices = auto.get("compare_prices", False)
    woolies_cart, coles_cart, comparisons = run_price_comparison_and_choose(
        cart, profile, compare_prices=compare_prices, dry_run=dry_run, headless=headless
    )
    if woolies_cart or coles_cart:
        print(f"\n  -> Woolworths: {len(woolies_cart)} items   Coles: {len(coles_cart)} items")

    if not auto_approve:
        if not ask_go_ahead("\nAdd these to your online cart? (You’ll pay at the store when you checkout.)"):
            print("No problem. Exiting.")
            return False
        print("Adding 1 of each ingredient (you can change quantities on the store site).")
        print("The browser will open the store site. Log in there first; nothing is added until you press Enter in the terminal.")

    Path("cart.json").write_text(json.dumps(cart, indent=2), encoding="utf-8")
    results = {"woolworths": None, "coles": None}
    to_fill_w = cart_for_browser(woolies_cart) if woolies_cart else []
    to_fill_c = cart_for_browser(coles_cart) if coles_cart else []
    to_fill_woolies = to_fill_w or (cart_for_browser(cart) if not to_fill_w and not to_fill_c else [])
    if to_fill_woolies:
        results["woolworths"] = run_woolies_fill(to_fill_woolies, profile, dry_run=dry_run, headless=headless, keep_browser_open=not dry_run)
    if to_fill_c:
        results["coles"] = run_coles_fill(to_fill_c, profile, dry_run=dry_run, headless=headless, keep_browser_open=not dry_run)

    # OBSERVE → LEARN: record failures for future substitutions
    for store_key in ("woolworths", "coles"):
        r = results.get(store_key)
        if r and r.get("failed"):
            profile.setdefault("learned_failures", [])
            for f in r["failed"]:
                profile["learned_failures"].append(
                    {"name": f.get("name"), "error": f.get("error"), "store": store_key, "at": datetime.now().isoformat()}
                )
    save_profile(profile)

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = LOG_DIR / f"run_{stamp}.json"
    log_payload = {
        "mode": "autonomous",
        "people": people,
        "days": days,
        "budget": budget,
        "avoid": avoid,
        "picks": picks,
        "cart": cart,
        "woolies_cart": woolies_cart,
        "coles_cart": coles_cart,
        "comparisons": comparisons,
        "results": results,
        "profile_after": profile,
    }
    log_path.write_text(json.dumps(log_payload, indent=2, default=str), encoding="utf-8")
    print(f"\nRun log: {log_path}")
    if results.get("woolworths", {}).get("dry_run") or results.get("coles", {}).get("dry_run"):
        print("(Test run - no browser used.)")
    else:
        for store_key in ("woolworths", "coles"):
            r = results.get(store_key)
            if r:
                added, failed = len(r.get("added", [])), len(r.get("failed", []))
                print(f"  {store_key}: {added} added" + (f", {failed} failed" if failed else ""))
        rw = results.get("woolworths") or results.get("coles")
        if rw and len(rw.get("added", [])) == 0 and len(rw.get("failed", [])) > 0:
            print("\n  Nothing was added to the cart. The store page may be slow or need sign-in.")
            print("  You can add items manually at woolworths.com.au or coles.com.au using cart.json.")
    return True


def run_interactive(profile: Dict[str, Any]) -> None:
    """Interactive flow with simple, friendly prompts."""
    print("\n  Hi — I’ll help you plan meals and fill your grocery cart.\n")

    people = prompt_int("How many people are you shopping for?", 2, 1, 10)
    days = prompt_int("Meal plan for how many days?", 5, 1, 14)
    budget = prompt_float("What’s your budget in dollars?", 140.0, 10.0, 5000.0)
    avoid = prompt_list("Any ingredients to avoid?")

    print("\nPick recipes by number (e.g. 1,2,3 for a few meals):")
    show_recipes()
    picks_raw = input("Your choice (e.g. 1,3,5 or all) [default: 1,2,3]: ").strip()
    if not picks_raw:
        picks_raw = "1,2,3"
    picks = parse_picks(picks_raw)
    if not picks:
        print("No recipes selected. See you next time.")
        return
    if picks_raw.strip().lower() == "all":
        print("  (You chose all recipes - that's a long list. You can remove items in the next step.)")

    cart, meal_plan_text, est = build_plan_and_cart(
        people=people,
        days=days,
        budget=budget,
        avoid=avoid,
        picks=picks,
        profile_subs=profile.get("substitutions", {}),
    )

    print("\n--- Your meal plan ---")
    print(meal_plan_text)
    print("\n--- Your cart ---")
    for line in cart:
        print(f"  - {line.get('name', '')} x{line.get('qty', 1)}")
    print(f"\nRough total: about ${est:.2f} (store prices may vary)")

    cart = review_cart(cart, budget, est)
    if not cart:
        print("No items left. Exiting.")
        return

    compare_prices = ask_yes_no("\nCompare Coles vs Woolworths and pick the cheaper option for each item?", default=False)
    woolies_cart, coles_cart, comparisons = run_price_comparison_and_choose(
        cart, profile, compare_prices=compare_prices
    )
    if woolies_cart or coles_cart:
        print(f"\n  -> Woolworths: {len(woolies_cart)} items   Coles: {len(coles_cart)} items")

    if not ask_go_ahead("\nAdd these to your online cart? (You’ll pay at checkout.)"):
        print("No problem. Come back whenever you’re ready.")
        return
    print("Adding 1 of each (only the items you kept in the list).")
    print("The browser will open the store site. Log in there first; nothing is added until you press Enter in the terminal.")

    Path("cart.json").write_text(json.dumps(cart, indent=2), encoding="utf-8")
    results = {"woolworths": None, "coles": None}
    to_fill_w = cart_for_browser(woolies_cart) if woolies_cart else []
    to_fill_c = cart_for_browser(coles_cart) if coles_cart else []
    to_fill_woolies = to_fill_w or (cart_for_browser(cart) if not to_fill_w and not to_fill_c else [])
    if to_fill_woolies:
        results["woolworths"] = run_woolies_fill(to_fill_woolies, profile, keep_browser_open=True)
    if to_fill_c:
        results["coles"] = run_coles_fill(to_fill_c, profile, keep_browser_open=True)

    for store_key in ("woolworths", "coles"):
        r = results.get(store_key)
        if r and r.get("failed"):
            profile.setdefault("learned_failures", [])
            for f in r["failed"]:
                profile["learned_failures"].append(
                    {"name": f.get("name"), "error": f.get("error"), "store": store_key, "at": datetime.now().isoformat()}
                )
    save_profile(profile)

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = LOG_DIR / f"run_{stamp}.json"
    log_path.write_text(
        json.dumps(
            {
                "people": people,
                "days": days,
                "budget": budget,
                "avoid": avoid,
                "picks": picks,
                "cart": cart,
                "woolies_cart": woolies_cart,
                "coles_cart": coles_cart,
                "comparisons": comparisons,
                "results": results,
                "profile_after": profile,
            },
            indent=2,
            default=str,
        ),
        encoding="utf-8",
    )
    print(f"\nDone. Run saved to {log_path}")
    for store_key in ("woolworths", "coles"):
        r = results.get(store_key)
        if r:
            added, failed = len(r.get("added", [])), len(r.get("failed", []))
            print(f"  {store_key}: {added} added" + (f", {failed} failed" if failed else ""))
    rw = results.get("woolworths") or results.get("coles")
    if rw and len(rw.get("added", [])) == 0 and len(rw.get("failed", [])) > 0:
        print("\n  Nothing was added. The store page may be slow or need sign-in.")
        print("  You can add items manually using the list in cart.json.")


def main() -> None:
    parser = argparse.ArgumentParser(description="Autonomous shopping agent (Woolworths)")
    parser.add_argument("--auto", action="store_true", help="Autonomous mode: use config.json, no prompts")
    parser.add_argument("--approve", action="store_true", help="In --auto, skip approval prompt and fill cart")
    parser.add_argument("--dry-run", action="store_true", help="Don’t open browser; simulate cart fill")
    parser.add_argument("--headless", action="store_true", help="Run browser headless (--auto only)")
    args = parser.parse_args()

    profile = load_profile()

    if args.auto:
        run_autonomous(profile, auto_approve=args.approve, dry_run=args.dry_run, headless=args.headless)
    else:
        run_interactive(profile)


if __name__ == "__main__":
    main()
